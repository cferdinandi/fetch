<?php

/**
 * Plugin Name: fetch-red-collar-5
 * Plugin URI: https://fetch.gomakethings.com
 * Description: The insanely easy to display a beautiful, mobile-friendly list of adoptable pets from Petfinder on your website.
 * Version: 5.0.0
 * Author: Chris Ferdinandi
 * Author URI: https://gomakethings.com
 * License: LicenseRef-See included LICENSE.md
 */

require_once( dirname( __FILE__) . "/fetch-red-collar-5-shortcode.php" );